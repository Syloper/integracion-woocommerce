<?php
 ?>
 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<h1>Integración WooCommerce</h1>
<?php $url = $_SERVER['REQUEST_URI'];
	  $url_2 = substr($url, 0, 35);
	  
	 ?>
<br><br>

<!-- <div align="center" class="col-md-12">
	<div class="col-md-10">
		<a href="/wp-admin/admin.php?page=iw-importarclientes" class="btn btn-success">Importar Clientes</a>
		<a href="/wp-admin/admin.php?page=iw-importapedidos" class="btn btn-danger">Importar Pedidos</a>
		<a href="/wp-admin/admin.php?page=iw-actualizarprecios" class="btn btn-warning">Modificar Precios</a>
	</div>
</div> -->
